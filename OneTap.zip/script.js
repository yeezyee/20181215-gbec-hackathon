var smartContractAddress = "0x70f4b4864b4df89bf3ba8fb9e9e72d4fe65334c4";

var abi =[
	{
		"constant": false,
		"inputs": [],
		"name": "owned",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "_allergies",
				"type": "string"
			}
		],
		"name": "setallergies",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "_bankAcc",
				"type": "string"
			}
		],
		"name": "setBankAcc",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "_birthday",
				"type": "string"
			}
		],
		"name": "setbirthday",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "_bloodtype",
				"type": "string"
			}
		],
		"name": "setbloodtype",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "_digitalHealthID",
				"type": "string"
			}
		],
		"name": "setdigitalHealthID",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "_e_walletAcc",
				"type": "string"
			}
		],
		"name": "setE_walletAcc",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "_emergencyContact",
				"type": "string"
			}
		],
		"name": "setemergencyContact",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "_FacebookAcc",
				"type": "string"
			}
		],
		"name": "setFacebookAcc",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "_homeAddress",
				"type": "string"
			}
		],
		"name": "sethomeAddress",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "_icNumber",
				"type": "string"
			}
		],
		"name": "seticNumber",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "_insurance",
				"type": "string"
			}
		],
		"name": "setinsurance",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "_LinkedInAcc",
				"type": "string"
			}
		],
		"name": "setLinkedInAcc",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "_medicalHistory",
				"type": "string"
			}
		],
		"name": "setmedicalHistory",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "_name",
				"type": "string"
			}
		],
		"name": "setName",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "_passportNum",
				"type": "string"
			}
		],
		"name": "setpassportNum",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "_skills",
				"type": "string"
			}
		],
		"name": "setskills",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "_surgeryHistory",
				"type": "string"
			}
		],
		"name": "setsurgeryHistory",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": false,
		"inputs": [
			{
				"name": "_workExp",
				"type": "string"
			}
		],
		"name": "setWorkExp",
		"outputs": [],
		"payable": false,
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "allergies",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "bankAcc",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "birthday",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "bloodtype",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "digitalHealthID",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "e_walletAcc",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "emergencyContact",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "FacebookAcc",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "getallergies",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "getBankAcc",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "getbirthday",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "getbloodtype",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "getdigitalHealthID",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "getE_walletAcc",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "getemergencyContact",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "getFacebookAcc",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "gethomeAddress",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "geticNumber",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "getinsurance",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "getLinkedAcc",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "getmedicalHistory",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "getName",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "getpassportNum",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "getskills",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "getsurgeryHistory",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "getWorkExp",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "homeAddress",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "icNumber",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "insurance",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "LinkedInAcc",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "medicalHistory",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "name",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "owner",
		"outputs": [
			{
				"name": "",
				"type": "address"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "passportNum",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "skills",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "surgeryHistory",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	},
	{
		"constant": true,
		"inputs": [],
		"name": "workExp",
		"outputs": [
			{
				"name": "",
				"type": "string"
			}
		],
		"payable": false,
		"stateMutability": "view",
		"type": "function"
	}
]

var myAccount;
var web3;

function initApp(){
  myAccount = web3.eth.accounts[0];
  myContract = web3.eth.contract(abi);
  contractInstance = myContract.at(smartContractAddress);
}

function set() {

  msgString = document.getElementById("_name").value;
  if(!msgString){
    return window.alert("MESSAGE VALUE IS EMPTY");
  }
  contractInstance.setName(msgString,{ 
    from: myAccount,
    gasPrice: "20000000000", 
   }, function(err, result) {
    if (!err){
      console.log('MESSAGE UPDATED IN BLOCKCHIAN SUCCESSFULLY',result); 
    }
    else{
      console.log(err);
    }
  });

  msgString = document.getElementById("_icNumber").value;
  if(!msgString){
    return window.alert("MESSAGE VALUE IS EMPTY");
  }
  contractInstance.seticNumber(msgString,{ 
    from: myAccount,
    gasPrice: "20000000000", 
   }, function(err, result) {
    if (!err){
      console.log('MESSAGE UPDATED IN BLOCKCHIAN SUCCESSFULLY',result); 
    }
    else{
      console.log(err);
    }
  });
  
  msgString = document.getElementById("_passportNum").value;
  if(!msgString){
    return window.alert("MESSAGE VALUE IS EMPTY");
  }
  contractInstance.setpassportNum(msgString,{ 
    from: myAccount,
    gasPrice: "20000000000", 
   }, function(err, result) {
    if (!err){
      console.log('MESSAGE UPDATED IN BLOCKCHIAN SUCCESSFULLY',result); 
    }
    else{
      console.log(err);
    }
  });
  
  msgString = document.getElementById("_birthday").value;
  if(!msgString){
    return window.alert("MESSAGE VALUE IS EMPTY");
  }
  contractInstance.setbirthday(msgString,{ 
    from: myAccount,
    gasPrice: "20000000000", 
   }, function(err, result) {
    if (!err){
      console.log('MESSAGE UPDATED IN BLOCKCHIAN SUCCESSFULLY',result); 
    }
    else{
      console.log(err);
    }
  });
  
  msgString = document.getElementById("_homeAddress").value;
  if(!msgString){
    return window.alert("MESSAGE VALUE IS EMPTY");
  }
  contractInstance.sethomeAddress(msgString,{ 
    from: myAccount,
    gasPrice: "20000000000", 
   }, function(err, result) {
    if (!err){
      console.log('MESSAGE UPDATED IN BLOCKCHIAN SUCCESSFULLY',result); 
    }
    else{
      console.log(err);
    }
  });

  msgString = document.getElementById("_allergies").value;
  if(!msgString){
    return window.alert("MESSAGE VALUE IS EMPTY");
  }
  contractInstance.setallergies(msgString,{ 
    from: myAccount,
    gasPrice: "20000000000", 
   }, function(err, result) {
    if (!err){
      console.log('MESSAGE UPDATED IN BLOCKCHIAN SUCCESSFULLY',result); 
    }
    else{
      console.log(err);
    }
  });

  msgString = document.getElementById("_bloodtype").value;
  if(!msgString){
    return window.alert("MESSAGE VALUE IS EMPTY");
  }
  contractInstance.setbloodtype(msgString,{ 
    from: myAccount,
    gasPrice: "20000000000", 
   }, function(err, result) {
    if (!err){
      console.log('MESSAGE UPDATED IN BLOCKCHIAN SUCCESSFULLY',result); 
    }
    else{
      console.log(err);
    }
  });

  msgString = document.getElementById("_medicalHistory").value;
  if(!msgString){
    return window.alert("MESSAGE VALUE IS EMPTY");
  }
  contractInstance.setmedicalHistory(msgString,{ 
    from: myAccount,
    gasPrice: "20000000000", 
   }, function(err, result) {
    if (!err){
      console.log('MESSAGE UPDATED IN BLOCKCHIAN SUCCESSFULLY',result); 
    }
    else{
      console.log(err);
    }
  });

  msgString = document.getElementById("_surgeryHistory").value;
  if(!msgString){
    return window.alert("MESSAGE VALUE IS EMPTY");
  }
  contractInstance.setsurgeryHistory(msgString,{ 
    from: myAccount,
    gasPrice: "20000000000", 
   }, function(err, result) {
    if (!err){
      console.log('MESSAGE UPDATED IN BLOCKCHIAN SUCCESSFULLY',result); 
    }
    else{
      console.log(err);
    }
  });

  msgString = document.getElementById("_insurance").value;
  if(!msgString){
    return window.alert("MESSAGE VALUE IS EMPTY");
  }
  contractInstance.setinsurance(msgString,{ 
    from: myAccount,
    gasPrice: "20000000000", 
   }, function(err, result) {
    if (!err){
      console.log('MESSAGE UPDATED IN BLOCKCHIAN SUCCESSFULLY',result); 
    }
    else{
      console.log(err);
    }
  });

  msgString = document.getElementById("_emergencyContact").value;
  if(!msgString){
    return window.alert("MESSAGE VALUE IS EMPTY");
  }
  contractInstance.setemergencyContact(msgString,{ 
    from: myAccount,
    gasPrice: "20000000000", 
   }, function(err, result) {
    if (!err){
      console.log('MESSAGE UPDATED IN BLOCKCHIAN SUCCESSFULLY',result); 
    }
    else{
      console.log(err);
    }
  });

  msgString = document.getElementById("_digitalHealthID").value;
  if(!msgString){
    return window.alert("MESSAGE VALUE IS EMPTY");
  }
  contractInstance.setdigitalHealthID(msgString,{ 
    from: myAccount,
    gasPrice: "20000000000", 
   }, function(err, result) {
    if (!err){
      console.log('MESSAGE UPDATED IN BLOCKCHIAN SUCCESSFULLY',result); 
    }
    else{
      console.log(err);
    }
  });

  msgString = document.getElementById("_bankAcc").value;
  if(!msgString){
    return window.alert("MESSAGE VALUE IS EMPTY");
  }
  contractInstance.setBankAcc(msgString,{ 
    from: myAccount,
    gasPrice: "20000000000", 
   }, function(err, result) {
    if (!err){
      console.log('MESSAGE UPDATED IN BLOCKCHIAN SUCCESSFULLY',result); 
    }
    else{
      console.log(err);
    }
  });

  msgString = document.getElementById("_e_walletAcc").value;
  if(!msgString){
    return window.alert("MESSAGE VALUE IS EMPTY");
  }
  contractInstance.setE_walletAcc(msgString,{ 
    from: myAccount,
    gasPrice: "20000000000", 
   }, function(err, result) {
    if (!err){
      console.log('MESSAGE UPDATED IN BLOCKCHIAN SUCCESSFULLY',result); 
    }
    else{
      console.log(err);
    }
  });

  msgString = document.getElementById("_workExp").value;
  if(!msgString){
    return window.alert("MESSAGE VALUE IS EMPTY");
  }
  contractInstance.setWorkExp(msgString,{ 
    from: myAccount,
    gasPrice: "20000000000", 
   }, function(err, result) {
    if (!err){
      console.log('MESSAGE UPDATED IN BLOCKCHIAN SUCCESSFULLY',result); 
    }
    else{
      console.log(err);
    }
  });

  msgString = document.getElementById("_skills").value;
  if(!msgString){
    return window.alert("MESSAGE VALUE IS EMPTY");
  }
  contractInstance.setskills(msgString,{ 
    from: myAccount,
    gasPrice: "20000000000", 
   }, function(err, result) {
    if (!err){
      console.log('MESSAGE UPDATED IN BLOCKCHIAN SUCCESSFULLY',result); 
    }
    else{
      console.log(err);
    }
  });

  msgString = document.getElementById("_LinkedInAcc").value;
  if(!msgString){
    return window.alert("MESSAGE VALUE IS EMPTY");
  }
  contractInstance.setLinkedInAcc(msgString,{ 
    from: myAccount,
    gasPrice: "20000000000", 
   }, function(err, result) {
    if (!err){
      console.log('MESSAGE UPDATED IN BLOCKCHIAN SUCCESSFULLY',result); 
    }
    else{
      console.log(err);
    }
  });

  msgString = document.getElementById("_FacebookAcc").value;
  if(!msgString){
    return window.alert("MESSAGE VALUE IS EMPTY");
  }
  contractInstance.setFacebookAcc(msgString,{ 
    from: myAccount,
    gasPrice: "20000000000", 
   }, function(err, result) {
    if (!err){
      console.log('MESSAGE UPDATED IN BLOCKCHIAN SUCCESSFULLY',result); 
    }
    else{
      console.log(err);
    }
  });

}

function refreshMessageValue(msgString) {
  
  contractInstance.getName({ 
    from: myAccount
   }, function(err, result) {
    if (!err){
      console.log('Fetched msg value from blockchain:',result); 
      document.getElementById("_name").placeholder = result;
    }
    else{
      console.log(err);
    }
  });

  contractInstance.geticNumber({ 
    from: myAccount
   }, function(err, result) {
    if (!err){
      console.log('Fetched msg value from blockchain:',result); 
      document.getElementById("_icNumber").placeholder = result;
    }
    else{
      console.log(err);
    }
  });

  contractInstance.getpassportNum({ 
    from: myAccount
   }, function(err, result) {
    if (!err){
      console.log('Fetched msg value from blockchain:',result); 
      document.getElementById("_passportNum").placeholder = result;
    }
    else{
      console.log(err);
    }
  });

  contractInstance.getbirthday({ 
    from: myAccount
   }, function(err, result) {
    if (!err){
      console.log('Fetched msg value from blockchain:',result); 
      document.getElementById("_birthday").placeholder = result;
    }
    else{
      console.log(err);
    }
  });

  contractInstance.gethomeAddress({ 
    from: myAccount
   }, function(err, result) {
    if (!err){
      console.log('Fetched msg value from blockchain:',result); 
      document.getElementById("_homeAddress").placeholder = result;
    }
    else{
      console.log(err);
    }
  });

  contractInstance.getallergies({ 
    from: myAccount
   }, function(err, result) {
    if (!err){
      console.log('Fetched msg value from blockchain:',result); 
      document.getElementById("_allergies").placeholder = result;
    }
    else{
      console.log(err);
    }
  });

  contractInstance.getbloodtype({ 
    from: myAccount
   }, function(err, result) {
    if (!err){
      console.log('Fetched msg value from blockchain:',result); 
      document.getElementById("_bloodtype").placeholder = result;
    }
    else{
      console.log(err);
    }
  });

  contractInstance.getmedicalHistory({ 
    from: myAccount
   }, function(err, result) {
    if (!err){
      console.log('Fetched msg value from blockchain:',result); 
      document.getElementById("_medicalHistory").placeholder = result;
    }
    else{
      console.log(err);
    }
  });

  contractInstance.getsurgeryHistory({ 
    from: myAccount
   }, function(err, result) {
    if (!err){
      console.log('Fetched msg value from blockchain:',result); 
      document.getElementById("_surgeryHistory").placeholder = result;
    }
    else{
      console.log(err);
    }
  });

  contractInstance.getinsurance({ 
    from: myAccount
   }, function(err, result) {
    if (!err){
      console.log('Fetched msg value from blockchain:',result); 
      document.getElementById("_insurance").placeholder=result;
    }
    else{
      console.log(err);
    }
  });

  contractInstance.getdigitalHealthID({ 
    from: myAccount
   }, function(err, result) {
    if (!err){
      console.log('Fetched msg value from blockchain:',result); 
      document.getElementById("_digitalHealthID").placeholder=result;
    }
    else{
      console.log(err);
    }
  });

  contractInstance.getemergencyContact({ 
    from: myAccount
   }, function(err, result) {
    if (!err){
      console.log('Fetched msg value from blockchain:',result); 
      document.getElementById("_emergencyContact").placeholder=result;
    }
    else{
      console.log(err);
    }
  });

  contractInstance.getBankAcc({ 
    from: myAccount
   }, function(err, result) {
    if (!err){
      console.log('Fetched msg value from blockchain:',result); 
      document.getElementById("_bankAcc").placeholder=result;
    }
    else{
      console.log(err);
    }
  });

  contractInstance.getE_walletAcc({ 
    from: myAccount
   }, function(err, result) {
    if (!err){
      console.log('Fetched msg value from blockchain:',result); 
      document.getElementById("_e_walletAcc").placeholder=result;
    }
    else{
      console.log(err);
    }
  });

  contractInstance.getWorkExp({ 
    from: myAccount
   }, function(err, result) {
    if (!err){
      console.log('Fetched msg value from blockchain:',result); 
      document.getElementById("_workExp").placeholder=result;
    }
    else{
      console.log(err);
    }
  });

  contractInstance.getskills({ 
    from: myAccount
   }, function(err, result) {
    if (!err){
      console.log('Fetched msg value from blockchain:',result); 
      document.getElementById("_skills").placeholder=result;
    }
    else{
      console.log(err);
    }
  });

  contractInstance.getLinkedAcc({ 
    from: myAccount
   }, function(err, result) {
    if (!err){
      console.log('Fetched msg value from blockchain:',result); 
      document.getElementById("_LinkedInAcc").placeholder=result;
    }
    else{
      console.log(err);
    }
  });

  contractInstance.getFacebookAcc({ 
    from: myAccount
   }, function(err, result) {
    if (!err){
      console.log('Fetched msg value from blockchain:',result); 
      document.getElementById("_FacebookAcc").placeholder=result;
    }
    else{
      console.log(err);
    }
  });
}



window.addEventListener('load', function() {
  if (typeof web3 !== 'undefined') {
    web3 = new Web3(web3.currentProvider);
  } else {
    console.log('METAMASK NOT DETECTED');
  }
  initApp();
})




